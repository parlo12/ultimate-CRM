<?php

return array(
    'intro' => 'This is the introduction of the plugin, feel free to modify this message in the translation file',
);
